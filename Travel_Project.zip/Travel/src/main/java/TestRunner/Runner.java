package TestRunner;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.TestNGCucumberRunner;

import cucumber.api.testng.CucumberFeatureWrapper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.ITestResult;
import org.testng.SkipException;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

/*import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;*/

//@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/resources/Features/Book.feature","src/test/resources/Features/Departure.feature" },
        glue = {"stepDefinitions"},
        tags = {"@Execute"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports/cucumber-pretty",
                "json:target/cucumber-reports/CucumberTestReport.json",
                "rerun:target/cucumber-reports/rerun.txt"
        },        monochrome = true,strict = true, dryRun = false
)


public class Runner 				
{		
	private TestNGCucumberRunner testNGCucumberRunner;
	  
    public static WebDriver driver=null;
    public static WebDriverWait wait;
    /*public static WebClient webClient = new WebClient();
	 public static HtmlPage page = null;*/
    
    private String featureName;
    
    public static JavascriptExecutor js = (JavascriptExecutor) Runner.driver ;
    
    @BeforeClass(alwaysRun = true)
    public void setUpCucumber()  {
    	     
    		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\srira\\Downloads\\chromedriver_win32_Verison85\\chromedriver.exe");
    		 
    		/*// driver= new HtmlUnitDriver(BrowserVersion.CHROME);
    		 java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
    		  java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
    	*/	 driver = new ChromeDriver();
			 driver.manage().window().maximize();
			 wait = new WebDriverWait(driver, 30);
			 testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	      }
    
    public void beforeMethod(Object[] params) {
        CucumberFeatureWrapper cucumberFeature = (CucumberFeatureWrapper) params[0];
        featureName = cucumberFeature.getCucumberFeature().getGherkinFeature().getName();
    }
 
    @Test(groups = "cucumber scenarios", description = "Runs Cucumber Scenarios", dataProvider = "Features")
    public void scenario(CucumberFeatureWrapper cucumberFeatureWrapper) throws Throwable {
        testNGCucumberRunner.runCucumber(cucumberFeatureWrapper.getCucumberFeature());
    }

    @DataProvider(name="Features")
    public Object[][] getFeatures()
    {
        /*if(testNGCucumberRunner == null){
            testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
        }*/
        return testNGCucumberRunner.provideFeatures();
    }
    @AfterClass(alwaysRun = true)
    public void tearDownClass() throws Exception {
        
       driver.quit();
       testNGCucumberRunner.finish();
    }
}


