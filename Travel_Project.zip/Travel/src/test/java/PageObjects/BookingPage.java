package PageObjects;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.net.URL;
import java.util.function.*;
import java.util.*;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

import org.openqa.selenium.support.ui.Select;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.TestRunner;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import TestRunner.Runner;

public class BookingPage<V> {
	
	 Actions builder = new Actions(Runner.driver);  
	 JavascriptExecutor js = (JavascriptExecutor) Runner.driver ;
	 
	public BookingPage(WebDriver driver) {
	     PageFactory.initElements(driver, this);   
	 }
	
	 By Phone=By.xpath("(//h2[@id='overview_title']");
	 By Price=By.xpath("//div[@id='price-pin_cc_newmarket']//span[@data-curr='GBP'][1]");
	
	 By Itenary =By.xpath("(//li[@id='itinerary_title_tab'])[1]");
	 By Day1button = By.xpath("//button[@id='itin_iter_1_day-button-nosub']");
	 By Day1Details = By.xpath("//div[@id='itin_iter_1_day-text']");
	 By Day2button = By.xpath("//button[@id='itin_iter_2_day-button-nosub']");
	 By Day2Details = By.xpath("//div[@id='itin_iter_2_day-text']");
	 
	 By bookonlinebutton = By.xpath("//div[@id='book-button-header']/div/button");
	 
	 By DetailsPageTitle = By.xpath("//div[@id='product_name']");
	 
	public void checkPriceandPhone() throws InterruptedException {
		
		  if(Runner.driver.findElement(By.xpath("(//a[@id='supplier-phone'])[1]")).isDisplayed()) {
		  System.out.println("Phone is Present"); }
		  
		  if(Runner.driver.findElement(Price).isDisplayed()) {
			  System.out.println("Price is Present"); }
	   	Runner.wait.until( (Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@id='overview_title']")));
		
		
	}
	public void Itenarybuttonclick() throws InterruptedException{
		Runner.driver.findElement(Itenary).click();
		Runner.driver.findElement(Day1button).click();
			
		Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.elementToBeClickable(Day2button));
				
		Runner.driver.findElement(Day2button).click();
	}
	
	public void VerifyItenaryDetails() throws InterruptedException{
		 if(Runner.driver.findElement(Day1Details).isDisplayed()) {
			  System.out.println("Day1 Details Present");
			  Thread.sleep(1000);}
		 if(Runner.driver.findElement(Day2Details).isDisplayed()) {
			  System.out.println("Day2 Details Present");
			  Thread.sleep(1000);}	  
	}
	public void clickbookOnline() throws InterruptedException{
		
		Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.presenceOfElementLocated(bookonlinebutton));

		/*
		 * builder.moveToElement(Runner.driver.findElement(bookonlinebutton)).click().
		 * keyDown(Keys.CONTROL) .sendKeys(Keys.ENTER)
		 * .keyUp(Keys.CONTROL).build().perform();
		 */
		Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.elementToBeClickable(bookonlinebutton));
	    Runner.driver.findElement(bookonlinebutton).click();
		Thread.sleep(2000);
	}
	
	public void VerfiyDeparturePageTitle() {
		if(Runner.driver.findElement(DetailsPageTitle).isDisplayed()) {
			System.out.println("Title contains India");
		}
	}
}
