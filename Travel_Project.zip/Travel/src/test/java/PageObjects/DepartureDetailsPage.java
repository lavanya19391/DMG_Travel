package PageObjects;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import TestRunner.Runner;
public class DepartureDetailsPage<V> {
	
	public DepartureDetailsPage(WebDriver driver) {
	     PageFactory.initElements(driver, this);   
	 }
	  JavascriptExecutor js = (JavascriptExecutor) Runner.driver;
		 
		
	  
		  By FirstAvailableDate=By.xpath("(//span[@data-curr='GBP'])[1]"); 
		  By CheckDateTitle=By.xpath("//h3[contains(text(),'Which departure')]"); 
		  By DateContinue=By.xpath("//div[@class='nbf_fancy_nbf_tpl_pms_continue nbf_fg_pms_button_text ']"); 
		  
		  By Transport = By.xpath("//h2[@class='nbf_tpl_pms_bf_transport_title']");
		  By DateNoted=By.xpath("//div[@class='nbf_tpl_pms_calendar_day_available nbf_tpl_pms_calendar_box nbf_pms_tpl_calendar_selecteddate']/div[@class='nbf_tpl_pms_calendar_box_dom']");
		 
		  By CheckDepartureDate= By.xpath("(//th[@class='nbf_tpl_pms_bf_transport_time rwd_fullwidth']//following::td[@class='nbf_tpl_pms_bf_transport_date rwd_fullwidth'])[1]");
		  By CheckReturnDate =By.xpath("(//th[@class='nbf_tpl_pms_bf_transport_time rwd_fullwidth']//following::td[@class='nbf_tpl_pms_bf_transport_date rwd_fullwidth'])[3]");
		  
		  
		  By Accom_Continue=By.xpath("//div[@class='nbf_fancy_nbf_tpl_pms_book_room nbf_fg_pms_button_text ']"); 
		  By Extras=By.xpath("//div[@class='nbf_fancy_extrasButton nbf_tpl_pms_bf_extrasButtonnbf_fg_pms_button_text nbf_tpl_pms_bf_extrasButton']"); 
		  
		  
		  
		  By Firstname = By.xpath("//input[@id='pax-a-first-1']"); 
		  By Lastname = By.xpath("//input[@id='pax-a-last-1']"); 
				  
		  
		  By Yourname = By.xpath("//input[@id='contact-name']"); 
		  By number = By.xpath("//input[@id='contact-mobile']"); 
		  By mail = By.xpath("//input[@id='contact-email']"); 
		  By address1 = By.xpath("//input[@id='contact-address1']"); 
		  By city = By.xpath("//input[@id='contact-city']"); 
		  By postcode = By.xpath("//input[@id='contact-postcode']"); 
		  
		  By DetailsContinue=By.xpath("//div[@class='nbf_button nbf_tpl_pms_button']");
		  
		  By SignupFirstName=By.xpath("//input[@name='vars[first_name]']");
		  By SignupLastName=By.xpath("//input[@name='vars[last_name]']");
		  By Signupemail=By.xpath("//input[@name='email']");
		  By SignupPostcode=By.xpath("//input[@name='vars[postcode]']");
		  By agree=By.xpath("//input[@name='vars[agree]']");
		  By signup=By.xpath("//input[@id='sign-up']");
		  
		  By SignupConfirm= By.xpath("//h2[text()='Thanks for signing up!']");
		  
		  public void selectNumberofPassengers() { 
		 
			  Runner.driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			  if(Runner.driver.findElement(CheckDateTitle).isDisplayed()) {
			  System.out.println("Date Could be selected");
		  
		   } 
		  } 
		  
		  public void clickDate() throws InterruptedException {
			  
			//  js.executeScript("window.scrollBy(0,500)");
			  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(FirstAvailableDate));
			 
			  retryingFindClick(FirstAvailableDate);
			 Runner.driver.findElement(FirstAvailableDate).click();
			  Runner.driver.findElement(DateContinue).click();
			  Thread.sleep(8000);
		  
		  }
		  
		  public void CheckDepatureDate(){
			  if(Runner.driver.findElement(CheckDepartureDate).getText().contains(Runner.driver.findElement(DateNoted).getText())) {
				  System.out.println("DepartureDate is Correct");
			  
			   } 
		  }
		  public void checkReturnDate() throws InterruptedException{
			  String Date=Runner.driver.findElement(DateNoted).getText();
			  int foo;
			  try {
			     foo = Integer.parseInt(Date);
			  }
			  catch (NumberFormatException e)
			  {
			     foo = 0;
			  }
			//  int ConvertDate= Integer.parseInt(Date);
			  int a =9;
			  int AddedNineDays = foo+a;
			  
			  String ReturnDate= Integer.toString(AddedNineDays);
			  
			  if(Runner.driver.findElement(CheckReturnDate).getText().contains(ReturnDate)) {
				  System.out.println("ReturnDate is Correct");			  
			   } 
			  Thread.sleep(8000);
		  }
		  public void Accomodation() throws InterruptedException {
			  
			  /*Runner.wait.until(ExpectedConditions.visibilityOfElementLocated(Accom_Continue));
			 
			  Runner.driver.findElement(Accom_Continue).click();*/
			  
			  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(Extras));
				
			  Runner.driver.findElement(Extras).click(); 
		   } 
		  
		  public void PassengerDetails() {
			  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(Firstname));
			  
			 
			  Runner.driver.findElement(Firstname).sendKeys("Test");
			  Runner.driver.findElement(Lastname).sendKeys("Test"); 
			
			  Runner.driver.findElement(Yourname).sendKeys("Test Test");
			  Runner.driver.findElement(number).sendKeys("07438006779");
			  Runner.driver.findElement(mail).sendKeys("test@gmail.com");
			  Runner.driver.findElement(address1).sendKeys("80 Road");
			  Runner.driver.findElement(city).sendKeys("Edinburgh");
			  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(postcode));
			  Runner.driver.findElement(postcode).sendKeys("EH11 4HT");
			 
			  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(DetailsContinue));		  
			  Runner.driver.findElement(DetailsContinue).click();
			 
			  if(Runner.driver.findElement(By.xpath("//h2[text()='Confirming - One moment please']")).isDisplayed()){
				  System.out.println("Completed Passenger Details");
			  }
				
			  
		  }
		 
		  public void signupforAlert() throws InterruptedException{ 
			 						  
			  Runner.driver.findElement(SignupFirstName).sendKeys("Test");
			  Runner.driver.findElement(SignupLastName).sendKeys("Testtwo");
			  Runner.driver.findElement(Signupemail).sendKeys("Testtwo@gmail.co");
			  Runner.driver.findElement(SignupPostcode).sendKeys("Testtwo@gmail.co");
			  Runner.driver.findElement(agree).click();
			  
			  if( Runner.driver.findElement(agree).isSelected()) {
				  System.out.println("Agreed");
			  }
			  Runner.driver.findElement(signup).click();
			  
			  Thread.sleep(2000);
			 // new WebDriverWait(Runner.driver, 10).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(SignupConfirm));

			try {  if( Runner.driver.findElement(SignupConfirm).isDisplayed()) {
				  System.out.println("SignupConfirmed");
			  }
			  
			  else {
				  Thread.sleep(2000);
				  if(Runner.driver.findElement(By.xpath("//h2[text()='Sign up for our Newsletter']")).isDisplayed()) {
					  System.out.println("SignupConfirmed");
				  }
				  else {
					  System.out.println("error"); 
				  }
			  }
			}catch(Exception e) {
				
			}
			  
		 }
		  public boolean retryingFindClick(By by) {
			    boolean result = false;
			    int attempts = 0;
			    while(attempts < 3) {
			        try {
			            Runner.driver.findElement(by).click();
			            result = true;
			            break;
			        } catch(StaleElementReferenceException e) {
			        }
			        attempts++;
			    }
			    return result;
			}
		 
}
