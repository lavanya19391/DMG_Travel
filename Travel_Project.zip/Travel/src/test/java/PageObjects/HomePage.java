package PageObjects;
import java.util.List;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import TestRunner.Runner;
public class HomePage<V> {
	//WebDriver wait;
	public HomePage(WebDriver driver) {
	     PageFactory.initElements(driver, this);   
	 }
	  JavascriptExecutor js = (JavascriptExecutor) Runner.driver;
		 
	 @FindBy(how = How.ID, using = "site-logo-stuck") 
	 private WebElement Title;
	 
	 @FindBy(how = How.ID, using = "searchtext_freetext_search_form") 
	 private WebElement SearchBox;
	 
	 @FindBy(how = How.ID, using = "iterator_1_product_custom_more-info-button") 
	 public WebElement MoreInfo;
	 
	// By MoreInfo= By.xpath("//div[@id='iterator_1_product_custom_price-cont']//following::button[@id='iterator_1_product_custom_more-info-button']"); 
	 
		 
	 public void VerifyTitle() throws InterruptedException {
		 if(Title.isDisplayed()) {
			 System.out.println("Title is Present"); 
		  }
		 }
	
	 public void sendSearch() {
			
		 SearchBox.sendKeys("India");
	 }
	 public void clickMoreInfo() {	 
		 Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.elementToBeClickable(MoreInfo));
		 MoreInfo.click();
	 }
	
	
	/*
	 *  public void clicksignin() {
	 	Runner.wait.until(ExpectedConditions.elementToBeClickable(Runner.driver.findElement(By.xpath("//button[@class='btn btn-primary btn-block']"))));
	 	JavascriptExecutor executor = (JavascriptExecutor)Runner.driver;
	 	executor.executeScript("arguments[0].click();", Runner.driver.findElement(By.xpath("//button[@class='btn btn-primary btn-block']")));
		
	}
	 * public void seeHomepage() {
	 * Runner.wait.until(ExpectedConditions.invisibilityOfElementLocated((By.
	 * xpath("//div[text()='Loading, please wait...']")))); }
	 */
			 
		 
	 
}
