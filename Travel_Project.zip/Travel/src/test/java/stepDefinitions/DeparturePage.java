package stepDefinitions;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static org.testng.Assert.*;

import org.testng.Assert;
import org.testng.annotations.*;

import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import TestRunner.Runner;

import org.apache.commons.io.*;

import PageObjects.*;

import org.openqa.selenium.support.ui.Select;

public class DeparturePage<V> {

	Actions builder = new Actions(Runner.driver);    

	DepartureDetailsPage dep=new DepartureDetailsPage(Runner.driver); 
	
	
	  @Given("^I select number of passengers$") 
	  public void i_select_number_of_passengers() throws Throwable {
		  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated((By.xpath("//select[@id='numAdults-98f14691e2018479869775ac1879f0dd']"))));		  

		  Select passengers = new Select(Runner.driver.findElement(By.xpath("//select[@id='numAdults-98f14691e2018479869775ac1879f0dd']")));
		  passengers.selectByValue("1");
		  dep.selectNumberofPassengers(); 
		  	
		 }
	  
	  @When("^I click first avilable date$") 
	  public void i_click_first_avilable_date() throws Throwable { 
		  dep.clickDate(); 
		  }
	  
	  @Then("^Departure Date is same as Selected Date$") 
	  public void i_checkDepartureDate() throws Throwable {
		  
		  builder.sendKeys(Keys.PAGE_UP).build().perform();
		  //Click Transport Details
		  
		  builder.sendKeys(Keys.PAGE_UP).build().perform();
		  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@class='nbf_tpl_pms_bf_transport_title']")));		  

		  Runner.driver.findElement(By.xpath("//h2[@class='nbf_tpl_pms_bf_transport_title']")).click();
		  
		  dep.CheckDepatureDate();
		  
		}
	  
	  @And("^Return Date is selected as plus 9 days from Departure$") 
	  public void i_CheckReturnDate() throws Throwable {
		  
		  dep.checkReturnDate();
	
		}
	  
	  @Then("^I provide Accomodation$") 
	  public void i_provide_Accomodation() throws Throwable { 
			/*
			 * Select options = new
			 * Select(Runner.driver.findElement(By.xpath("//select[@id='room-0-numselect']")
			 * )); options.selectByValue("1");
			 */
		  
		  builder.sendKeys(Keys.PAGE_DOWN).build().perform();
		  Runner.driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		  dep.Accomodation(); 
		 }
	  
	  @And("^I fill Passenger Details$") 
	  public void i_fill_Passenger_Details() throws Throwable { 
		  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated((By.xpath("//select[@id='pax-a-title-1']"))));		  
		  Thread.sleep(2000);	
		  Select Title = new Select(Runner.driver.findElement(By.xpath("//select[@id='pax-a-title-1']")));
		  Runner.driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		  Title.selectByValue("Mr");
		  Select D = new Select(Runner.driver.findElement(By.xpath("//select[@id='pax-a-dobd-1']")));
		  Select M = new Select(Runner.driver.findElement(By.xpath("//select[@id='pax-a-dobm-1']")));
		  Select Y = new Select(Runner.driver.findElement(By.xpath("//select[@id='pax-a-doby-1']")));
		  D.selectByValue("2");
		  M.selectByValue("2"); 
		  Y.selectByValue("2004");
		  dep.PassengerDetails(); 
			/*
			 * Select Country = new
			 * Select(Runner.driver.findElement(By.xpath("//select[@id='contact-country']"))
			 * ); Country.selectByValue("UK");
			 */ 
	  }
	  
	  @Then("^I signup for Alert$") 
	  public void i_signup_for_Alert() throws Throwable {
		
		  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@title='Sign up to our newsletter']")));		  	 
		  Runner.driver.findElement(By.xpath("//a[@title='Sign up to our newsletter']")).click();
		  
		  Runner.wait.until((Function<? super WebDriver, V>) ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='vars[first_name]']")));		  	 
			 
		  Select Titl = new Select(Runner.driver.findElement(By.xpath("//select[@name='vars[title]']")));
		  Titl.selectByValue("mr");
		  dep.signupforAlert(); 
		 
		  }
	 
	 
}
