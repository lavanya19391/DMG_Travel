
package stepDefinitions;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static org.testng.Assert.*;

import org.testng.Assert;
import org.testng.annotations.*;

import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import TestRunner.Runner;

import org.apache.commons.io.*;

import PageObjects.*;

import org.openqa.selenium.support.ui.Select;
public  class HomeBookingPage{

	Actions builder = new Actions(Runner.driver);    

    JavascriptExecutor js = (JavascriptExecutor) Runner.driver;

	HomePage home=new HomePage(Runner.driver);;
	BookingPage book=new BookingPage(Runner.driver); ;
	

	@Given("^I navigate to the given URL$")
	public void i_navigate_to_the_given_URL() throws Throwable {
		Runner.driver.navigate().to("https://www.mailtravel.co.uk/");
		Thread.sleep(2000);
		System.out.print("URL Opened");
		Runner.driver.findElement(By.xpath("(//button[@title='Close'])[1]")).click();
	}

	@When("^I see title of the application$")
	public void i_see_title_of_the_application() throws Throwable {
	  home.VerifyTitle();
	}

	@Then("^I search India in search box$")
	public void i_search_in_search_box() throws Throwable {
		home.sendSearch();
		
		builder.sendKeys(Keys.ENTER).build().perform();
		
	}

	@And("^I click More info on India - TajMahal package$")
	public void i_clickMoreInfo() throws Throwable {
	//	builder.sendKeys(Keys.PAGE_UP).build().perform();
	//	js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(3000);
		home.clickMoreInfo();
		
	}

	@Given("^I see contact number and price$")
	public void i_see_contact_number_and_price() throws Throwable {
		
		Runner.driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		
		builder.sendKeys(Keys.PAGE_DOWN).build().perform();
		Runner.driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
	    /*
		 * js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		 * js.executeScript("window.scrollBy(0,1000)");
		 */
		book.checkPriceandPhone();
	}
	@When("^I click on Itenary$")
	public void i_click_Itenary() throws Throwable {
		
		 book.Itenarybuttonclick();
	}
	
	@Then("^I see Details of Itenary$")
	public void i_seeItenaryDetails() throws Throwable {
		
		 book.VerifyItenaryDetails();
	}
	
	
	@When("^I click book online button$")
	public void i_click_book_online_button() throws Throwable {
	//	builder.sendKeys(Keys.PAGE_DOWN).build().perform();
		builder.sendKeys(Keys.PAGE_UP).build().perform();
			
		Runner.driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	  // js.executeScript("window.scrollBy(550,0)");
	
		book.clickbookOnline();
		Runner.driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		
	}
	@Then("^I proceed to Departure page$")
	public void i_proceed_to_Departure_page() throws Throwable {
		
		 book.VerfiyDeparturePageTitle();
	}
	
	
	

}